﻿namespace assignment.Joy_Model
{
    public class user
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
    }
}
